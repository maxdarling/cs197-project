//
//  BaseTable.hpp
//  
//
//  Created by Max  on 11/26/19.
//

class BaseTable {
public:
    virtual void insert(int key, int val) = 0;
};
